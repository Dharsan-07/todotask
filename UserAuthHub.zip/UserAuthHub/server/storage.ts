import { users, projects, activities, tasks, type User, type InsertUser, type Project, type InsertProject, type Activity, type InsertActivity, type Task, type InsertTask } from "@shared/schema";
import { db } from "./db";
import { eq } from "drizzle-orm";
import bcrypt from "bcrypt";

export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, user: Partial<InsertUser>): Promise<User | undefined>;
  getAllUsers(): Promise<User[]>;
  validatePassword(user: User, password: string): Promise<boolean>;

  // Project operations
  getProject(id: number): Promise<Project | undefined>;
  getProjectsByOwner(ownerId: number): Promise<Project[]>;
  getAllProjects(): Promise<Project[]>;
  createProject(project: InsertProject): Promise<Project>;
  updateProject(id: number, project: Partial<InsertProject>): Promise<Project | undefined>;
  deleteProject(id: number): Promise<boolean>;

  // Activity operations
  getActivities(limit?: number): Promise<Activity[]>;
  getActivitiesByUser(userId: number, limit?: number): Promise<Activity[]>;
  createActivity(activity: InsertActivity): Promise<Activity>;

  // Task operations
  getTask(id: number): Promise<Task | undefined>;
  getAllTasks(): Promise<Task[]>;
  getTasksByAssignee(assigneeId: number): Promise<Task[]>;
  getTasksByProject(projectId: number): Promise<Task[]>;
  createTask(task: InsertTask): Promise<Task>;
  updateTask(id: number, task: Partial<InsertTask>): Promise<Task | undefined>;
  deleteTask(id: number): Promise<boolean>;

  // Dashboard stats
  getDashboardStats(): Promise<{
    totalRevenue: string;
    activeUsers: number;
    totalProjects: number;
    conversionRate: string;
  }>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private projects: Map<number, Project>;
  private activities: Map<number, Activity>;
  private tasks: Map<number, Task>;
  private currentUserId: number;
  private currentProjectId: number;
  private currentActivityId: number;
  private currentTaskId: number;

  constructor() {
    this.users = new Map();
    this.projects = new Map();
    this.activities = new Map();
    this.tasks = new Map();
    this.currentUserId = 1;
    this.currentProjectId = 1;
    this.currentActivityId = 1;
    this.currentTaskId = 1;
    this.seedData();
  }

  private async seedData() {
    // Create admin user
    const adminUser: User = {
      id: this.currentUserId++,
      username: "admin",
      email: "admin@company.com",
      password: await bcrypt.hash("password123", 10),
      firstName: "Rajesh",
      lastName: "Sharma",
      role: "admin",
      avatar: null,
      isActive: true,
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    this.users.set(adminUser.id, adminUser);

    // Create sample users with Indian names
    const sampleUsers = [
      {
        username: "priya.patel",
        email: "priya.patel@techcorp.in",
        firstName: "Priya",
        lastName: "Patel",
        role: "manager" as const,
        avatar: null,
      },
      {
        username: "ankit.gupta",
        email: "ankit.gupta@techcorp.in",
        firstName: "Ankit",
        lastName: "Gupta",
        role: "user" as const,
        avatar: null,
      },
      {
        username: "sneha.reddy",
        email: "sneha.reddy@techcorp.in",
        firstName: "Sneha",
        lastName: "Reddy",
        role: "user" as const,
        avatar: null,
      },
    ];

    for (const userData of sampleUsers) {
      const user: User = {
        id: this.currentUserId++,
        ...userData,
        password: await bcrypt.hash("password123", 10),
        isActive: true,
        createdAt: new Date(),
        updatedAt: new Date(),
      };
      this.users.set(user.id, user);
    }

    // Create sample projects with Indian business context
    const sampleProjects: Project[] = [
      {
        id: this.currentProjectId++,
        name: "E-commerce Platform for MSME",
        description: "Digital platform to support Micro, Small and Medium Enterprises in India",
        status: "active",
        ownerId: 2,
        createdAt: new Date(),
        updatedAt: new Date(),
      },
      {
        id: this.currentProjectId++,
        name: "Digital Payment Integration",
        description: "Integration with UPI, BHIM and other Indian payment gateways",
        status: "active",
        ownerId: 3,
        createdAt: new Date(),
        updatedAt: new Date(),
      },
      {
        id: this.currentProjectId++,
        name: "Rural Healthcare App",
        description: "Telemedicine app for rural areas with regional language support",
        status: "completed",
        ownerId: 4,
        createdAt: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000),
        updatedAt: new Date(),
      },
    ];

    sampleProjects.forEach(project => {
      this.projects.set(project.id, project);
    });

    // Create sample activities with Indian business context
    const sampleActivities: Activity[] = [
      {
        id: this.currentActivityId++,
        userId: 2,
        action: "created project",
        target: "E-commerce Platform for MSME",
        targetType: "project",
        createdAt: new Date(Date.now() - 2 * 60 * 60 * 1000),
      },
      {
        id: this.currentActivityId++,
        userId: 3,
        action: "completed task",
        target: "UPI Payment Gateway Integration",
        targetType: "task",
        createdAt: new Date(Date.now() - 4 * 60 * 60 * 1000),
      },
      {
        id: this.currentActivityId++,
        userId: 4,
        action: "uploaded design files for",
        target: "Rural Healthcare App",
        targetType: "project",
        createdAt: new Date(Date.now() - 6 * 60 * 60 * 1000),
      },
      {
        id: this.currentActivityId++,
        userId: 1,
        action: "approved budget for",
        target: "Digital Payment Integration",
        targetType: "project",
        createdAt: new Date(Date.now() - 12 * 60 * 60 * 1000),
      },
      {
        id: this.currentActivityId++,
        userId: 3,
        action: "started working on",
        target: "Multi-language Support for Hindi",
        targetType: "task",
        createdAt: new Date(Date.now() - 18 * 60 * 60 * 1000),
      },
    ];

    sampleActivities.forEach(activity => {
      this.activities.set(activity.id, activity);
    });

    // Create sample tasks with Indian business context
    const sampleTasks: Task[] = [
      {
        id: this.currentTaskId++,
        title: "Implement UPI Payment Gateway",
        description: "Integrate UPI payment system for seamless transactions",
        status: "in_progress",
        priority: "high",
        assigneeId: 2,
        projectId: 2,
        dueDate: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000),
        createdAt: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000),
        updatedAt: new Date(),
      },
      {
        id: this.currentTaskId++,
        title: "Multi-language Support for Hindi",
        description: "Add Hindi language support for better accessibility",
        status: "pending",
        priority: "medium",
        assigneeId: 3,
        projectId: 1,
        dueDate: new Date(Date.now() + 14 * 24 * 60 * 60 * 1000),
        createdAt: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000),
        updatedAt: new Date(),
      },
      {
        id: this.currentTaskId++,
        title: "GSTIN Validation Module",
        description: "Create module to validate Indian GST identification numbers",
        status: "completed",
        priority: "high",
        assigneeId: 4,
        projectId: 1,
        dueDate: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000),
        createdAt: new Date(Date.now() - 10 * 24 * 60 * 60 * 1000),
        updatedAt: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000),
      },
      {
        id: this.currentTaskId++,
        title: "Regional Banking Integration",
        description: "Integrate with regional banks for broader financial inclusion",
        status: "pending",
        priority: "urgent",
        assigneeId: 2,
        projectId: 2,
        dueDate: new Date(Date.now() + 3 * 24 * 60 * 60 * 1000),
        createdAt: new Date(),
        updatedAt: new Date(),
      },
    ];

    sampleTasks.forEach(task => {
      this.tasks.set(task.id, task);
    });
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(user => user.email === email);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(user => user.username === username);
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const hashedPassword = await bcrypt.hash(insertUser.password, 10);
    const user: User = {
      id: this.currentUserId++,
      username: insertUser.username,
      email: insertUser.email,
      password: hashedPassword,
      firstName: insertUser.firstName,
      lastName: insertUser.lastName,
      role: insertUser.role || "user",
      avatar: insertUser.avatar || null,
      isActive: insertUser.isActive ?? true,
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    this.users.set(user.id, user);
    return user;
  }

  async updateUser(id: number, updateData: Partial<InsertUser>): Promise<User | undefined> {
    const user = this.users.get(id);
    if (!user) return undefined;

    const updatedUser: User = {
      ...user,
      ...updateData,
      updatedAt: new Date(),
    };
    this.users.set(id, updatedUser);
    return updatedUser;
  }

  async getAllUsers(): Promise<User[]> {
    return Array.from(this.users.values());
  }

  async validatePassword(user: User, password: string): Promise<boolean> {
    return bcrypt.compare(password, user.password);
  }

  async getProject(id: number): Promise<Project | undefined> {
    return this.projects.get(id);
  }

  async getProjectsByOwner(ownerId: number): Promise<Project[]> {
    return Array.from(this.projects.values()).filter(project => project.ownerId === ownerId);
  }

  async getAllProjects(): Promise<Project[]> {
    return Array.from(this.projects.values());
  }

  async createProject(insertProject: InsertProject): Promise<Project> {
    const project: Project = {
      id: this.currentProjectId++,
      name: insertProject.name,
      description: insertProject.description || null,
      status: insertProject.status || "active",
      ownerId: insertProject.ownerId,
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    this.projects.set(project.id, project);
    return project;
  }

  async updateProject(id: number, updateData: Partial<InsertProject>): Promise<Project | undefined> {
    const project = this.projects.get(id);
    if (!project) return undefined;

    const updatedProject: Project = {
      ...project,
      ...updateData,
      updatedAt: new Date(),
    };
    this.projects.set(id, updatedProject);
    return updatedProject;
  }

  async deleteProject(id: number): Promise<boolean> {
    return this.projects.delete(id);
  }

  async getActivities(limit: number = 50): Promise<Activity[]> {
    return Array.from(this.activities.values())
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime())
      .slice(0, limit);
  }

  async getActivitiesByUser(userId: number, limit: number = 50): Promise<Activity[]> {
    return Array.from(this.activities.values())
      .filter(activity => activity.userId === userId)
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime())
      .slice(0, limit);
  }

  async createActivity(insertActivity: InsertActivity): Promise<Activity> {
    const activity: Activity = {
      id: this.currentActivityId++,
      userId: insertActivity.userId,
      action: insertActivity.action,
      target: insertActivity.target || null,
      targetType: insertActivity.targetType || null,
      createdAt: new Date(),
    };
    this.activities.set(activity.id, activity);
    return activity;
  }

  async getDashboardStats(): Promise<{
    totalRevenue: string;
    activeUsers: number;
    totalProjects: number;
    conversionRate: string;
  }> {
    const activeUsers = Array.from(this.users.values()).filter(user => user.isActive).length;
    const totalProjects = this.projects.size;
    
    return {
      totalRevenue: "₹42,15,000",
      activeUsers,
      totalProjects,
      conversionRate: "3.24%",
    };
  }

  // Task operations
  async getTask(id: number): Promise<Task | undefined> {
    return this.tasks.get(id);
  }

  async getAllTasks(): Promise<Task[]> {
    return Array.from(this.tasks.values())
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
  }

  async getTasksByAssignee(assigneeId: number): Promise<Task[]> {
    return Array.from(this.tasks.values())
      .filter(task => task.assigneeId === assigneeId)
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
  }

  async getTasksByProject(projectId: number): Promise<Task[]> {
    return Array.from(this.tasks.values())
      .filter(task => task.projectId === projectId)
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
  }

  async createTask(insertTask: InsertTask): Promise<Task> {
    const task: Task = {
      id: this.currentTaskId++,
      title: insertTask.title,
      description: insertTask.description || null,
      status: insertTask.status || "pending",
      priority: insertTask.priority || "medium",
      assigneeId: insertTask.assigneeId || null,
      projectId: insertTask.projectId || null,
      dueDate: insertTask.dueDate || null,
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    this.tasks.set(task.id, task);
    return task;
  }

  async updateTask(id: number, updateData: Partial<InsertTask>): Promise<Task | undefined> {
    const task = this.tasks.get(id);
    if (!task) return undefined;

    const updatedTask: Task = {
      ...task,
      ...updateData,
      updatedAt: new Date(),
    };
    this.tasks.set(id, updatedTask);
    return updatedTask;
  }

  async deleteTask(id: number): Promise<boolean> {
    return this.tasks.delete(id);
  }
}

export class DatabaseStorage implements IStorage {
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.email, email));
    return user || undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const hashedPassword = await bcrypt.hash(insertUser.password, 10);
    const userData = {
      ...insertUser,
      password: hashedPassword,
    };
    const [user] = await db.insert(users).values(userData).returning();
    return user;
  }

  async updateUser(id: number, updateData: Partial<InsertUser>): Promise<User | undefined> {
    const [user] = await db
      .update(users)
      .set({ ...updateData, updatedAt: new Date() })
      .where(eq(users.id, id))
      .returning();
    return user || undefined;
  }

  async getAllUsers(): Promise<User[]> {
    return await db.select().from(users);
  }

  async validatePassword(user: User, password: string): Promise<boolean> {
    return await bcrypt.compare(password, user.password);
  }

  async getProject(id: number): Promise<Project | undefined> {
    const [project] = await db.select().from(projects).where(eq(projects.id, id));
    return project || undefined;
  }

  async getProjectsByOwner(ownerId: number): Promise<Project[]> {
    return await db.select().from(projects).where(eq(projects.ownerId, ownerId));
  }

  async getAllProjects(): Promise<Project[]> {
    return await db.select().from(projects);
  }

  async createProject(insertProject: InsertProject): Promise<Project> {
    const [project] = await db.insert(projects).values(insertProject).returning();
    return project;
  }

  async updateProject(id: number, updateData: Partial<InsertProject>): Promise<Project | undefined> {
    const [project] = await db
      .update(projects)
      .set({ ...updateData, updatedAt: new Date() })
      .where(eq(projects.id, id))
      .returning();
    return project || undefined;
  }

  async deleteProject(id: number): Promise<boolean> {
    const result = await db.delete(projects).where(eq(projects.id, id));
    return result.rowCount !== null && result.rowCount > 0;
  }

  async getActivities(limit: number = 50): Promise<Activity[]> {
    return await db.select().from(activities).limit(limit).orderBy(activities.createdAt);
  }

  async getActivitiesByUser(userId: number, limit: number = 50): Promise<Activity[]> {
    return await db
      .select()
      .from(activities)
      .where(eq(activities.userId, userId))
      .limit(limit)
      .orderBy(activities.createdAt);
  }

  async createActivity(insertActivity: InsertActivity): Promise<Activity> {
    const [activity] = await db.insert(activities).values(insertActivity).returning();
    return activity;
  }

  async getTask(id: number): Promise<Task | undefined> {
    const [task] = await db.select().from(tasks).where(eq(tasks.id, id));
    return task || undefined;
  }

  async getAllTasks(): Promise<Task[]> {
    return await db.select().from(tasks).orderBy(tasks.createdAt);
  }

  async getTasksByAssignee(assigneeId: number): Promise<Task[]> {
    return await db
      .select()
      .from(tasks)
      .where(eq(tasks.assigneeId, assigneeId))
      .orderBy(tasks.createdAt);
  }

  async getTasksByProject(projectId: number): Promise<Task[]> {
    return await db
      .select()
      .from(tasks)
      .where(eq(tasks.projectId, projectId))
      .orderBy(tasks.createdAt);
  }

  async createTask(insertTask: InsertTask): Promise<Task> {
    const [task] = await db.insert(tasks).values(insertTask).returning();
    return task;
  }

  async updateTask(id: number, updateData: Partial<InsertTask>): Promise<Task | undefined> {
    const [task] = await db
      .update(tasks)
      .set({ ...updateData, updatedAt: new Date() })
      .where(eq(tasks.id, id))
      .returning();
    return task || undefined;
  }

  async deleteTask(id: number): Promise<boolean> {
    const result = await db.delete(tasks).where(eq(tasks.id, id));
    return result.rowCount !== null && result.rowCount > 0;
  }

  async getDashboardStats(): Promise<{
    totalRevenue: string;
    activeUsers: number;
    totalProjects: number;
    conversionRate: string;
  }> {
    const allUsers = await db.select().from(users);
    const allProjects = await db.select().from(projects);
    
    const activeUsers = allUsers.filter(user => user.isActive).length;
    const totalProjects = allProjects.length;
    
    return {
      totalRevenue: "₹42,15,000",
      activeUsers,
      totalProjects,
      conversionRate: "3.24%",
    };
  }
}

export const storage = new DatabaseStorage();

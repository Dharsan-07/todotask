import { db } from "./db";
import { users, projects, activities, tasks } from "@shared/schema";
import bcrypt from "bcrypt";

async function seedDatabase() {
  try {
    console.log("🌱 Seeding database...");

    // Create admin user
    const hashedPassword = await bcrypt.hash("password123", 10);
    const [adminUser] = await db.insert(users).values({
      username: "admin",
      email: "admin@company.com",
      password: hashedPassword,
      firstName: "Rajesh",
      lastName: "Sharma",
      role: "admin",
      avatar: null,
      isActive: true,
    }).returning();

    // Create sample users with Indian names
    const sampleUsers = [
      {
        username: "priya.patel",
        email: "priya.patel@techcorp.in",
        firstName: "Priya",
        lastName: "Patel",
        role: "manager" as const,
        avatar: null,
      },
      {
        username: "ankit.gupta",
        email: "ankit.gupta@techcorp.in",
        firstName: "Ankit",
        lastName: "Gupta",
        role: "user" as const,
        avatar: null,
      },
      {
        username: "sneha.reddy",
        email: "sneha.reddy@techcorp.in",
        firstName: "Sneha",
        lastName: "Reddy",
        role: "user" as const,
        avatar: null,
      },
    ];

    const createdUsers = [];
    for (const userData of sampleUsers) {
      const [user] = await db.insert(users).values({
        ...userData,
        password: hashedPassword,
        isActive: true,
      }).returning();
      createdUsers.push(user);
    }

    console.log(`✅ Created ${createdUsers.length + 1} users`);

    // Create sample projects with Indian business context
    const sampleProjects = [
      {
        name: "E-commerce Platform for MSME",
        description: "Digital platform to support Micro, Small and Medium Enterprises in India",
        status: "active" as const,
        ownerId: createdUsers[0].id,
      },
      {
        name: "Digital Payment Integration",
        description: "Integration with UPI, BHIM and other Indian payment gateways",
        status: "active" as const,
        ownerId: createdUsers[1].id,
      },
      {
        name: "Rural Healthcare App",
        description: "Telemedicine app for rural areas with regional language support",
        status: "completed" as const,
        ownerId: createdUsers[2].id,
      },
    ];

    const createdProjects = await db.insert(projects).values(sampleProjects).returning();
    console.log(`✅ Created ${createdProjects.length} projects`);

    // Create sample tasks with Indian business context
    const sampleTasks = [
      {
        title: "Implement UPI Payment Gateway",
        description: "Integrate UPI payment system for seamless transactions",
        status: "in_progress" as const,
        priority: "high" as const,
        assigneeId: createdUsers[0].id,
        projectId: createdProjects[1].id,
        dueDate: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000),
      },
      {
        title: "Multi-language Support for Hindi",
        description: "Add Hindi language support for better accessibility",
        status: "pending" as const,
        priority: "medium" as const,
        assigneeId: createdUsers[1].id,
        projectId: createdProjects[0].id,
        dueDate: new Date(Date.now() + 14 * 24 * 60 * 60 * 1000),
      },
      {
        title: "GSTIN Validation Module",
        description: "Create module to validate Indian GST identification numbers",
        status: "completed" as const,
        priority: "high" as const,
        assigneeId: createdUsers[2].id,
        projectId: createdProjects[0].id,
        dueDate: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000),
      },
      {
        title: "Regional Banking Integration",
        description: "Integrate with regional banks for broader financial inclusion",
        status: "pending" as const,
        priority: "urgent" as const,
        assigneeId: createdUsers[0].id,
        projectId: createdProjects[1].id,
        dueDate: new Date(Date.now() + 3 * 24 * 60 * 60 * 1000),
      },
    ];

    const createdTasks = await db.insert(tasks).values(sampleTasks).returning();
    console.log(`✅ Created ${createdTasks.length} tasks`);

    // Create sample activities with Indian business context
    const sampleActivities = [
      {
        userId: createdUsers[0].id,
        action: "created project",
        target: "E-commerce Platform for MSME",
        targetType: "project" as const,
      },
      {
        userId: createdUsers[1].id,
        action: "completed task",
        target: "UPI Payment Gateway Integration",
        targetType: "task" as const,
      },
      {
        userId: createdUsers[2].id,
        action: "uploaded design files for",
        target: "Rural Healthcare App",
        targetType: "project" as const,
      },
      {
        userId: adminUser.id,
        action: "approved budget for",
        target: "Digital Payment Integration",
        targetType: "project" as const,
      },
      {
        userId: createdUsers[1].id,
        action: "started working on",
        target: "Multi-language Support for Hindi",
        targetType: "task" as const,
      },
    ];

    const createdActivities = await db.insert(activities).values(sampleActivities).returning();
    console.log(`✅ Created ${createdActivities.length} activities`);

    console.log("🎉 Database seeding completed successfully!");
    
  } catch (error) {
    console.error("❌ Error seeding database:", error);
    throw error;
  }
}

// Run seeding if this file is executed directly
if (import.meta.url === `file://${process.argv[1]}`) {
  seedDatabase()
    .then(() => process.exit(0))
    .catch(() => process.exit(1));
}

export { seedDatabase };
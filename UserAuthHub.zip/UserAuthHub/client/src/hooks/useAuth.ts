import { useContext } from "react";
import { useAuth as useAuthContext } from "@/components/auth/AuthProvider";

export const useAuth = useAuthContext;

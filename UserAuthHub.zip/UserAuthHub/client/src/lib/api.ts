import { apiRequest } from "./queryClient";

export const api = {
  // Auth endpoints
  login: (email: string, password: string) =>
    apiRequest("POST", "/api/auth/login", { email, password }),

  register: (userData: any) =>
    apiRequest("POST", "/api/auth/register", userData),

  logout: () =>
    apiRequest("POST", "/api/auth/logout"),

  // Dashboard endpoints
  getDashboardStats: () =>
    fetch("/api/dashboard/stats").then(res => res.json()),

  getActivities: (limit?: number) =>
    fetch(`/api/activities${limit ? `?limit=${limit}` : ""}`).then(res => res.json()),

  // User endpoints
  getUsers: () =>
    fetch("/api/users").then(res => res.json()),

  // Project endpoints
  getProjects: () =>
    fetch("/api/projects").then(res => res.json()),

  createProject: (projectData: any) =>
    apiRequest("POST", "/api/projects", projectData),
};

import { Link, useLocation } from "wouter";
import { useAuth } from "@/components/auth/AuthProvider";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { 
  Home, 
  BarChart3, 
  Users, 
  Folder, 
  FileText, 
  Settings, 
  LogOut,
  TrendingUp,
  Plus,
  CheckSquare
} from "lucide-react";
import { cn } from "@/lib/utils";

const navigationItems = [
  { href: "/dashboard", icon: Home, label: "Dashboard" },
  { href: "/analytics", icon: BarChart3, label: "Analytics" },
  { href: "/users", icon: Users, label: "User Management" },
  { href: "/projects", icon: Folder, label: "Projects" },
  { href: "/tasks", icon: CheckSquare, label: "Tasks" },
  { href: "/reports", icon: FileText, label: "Reports" },
  { href: "/settings", icon: Settings, label: "Settings" },
];

export function Sidebar() {
  const [location] = useLocation();
  const { user, logout } = useAuth();

  if (!user) return null;

  return (
    <div className="fixed inset-y-0 left-0 z-50 w-64 bg-sidebar border-r border-sidebar-border shadow-lg">
      {/* Logo */}
      <div className="flex items-center px-6 py-4 border-b border-sidebar-border">
        <div className="h-10 w-10 bg-primary rounded-lg flex items-center justify-center mr-3">
          <TrendingUp className="h-6 w-6 text-primary-foreground" />
        </div>
        <span className="text-xl font-bold text-sidebar-foreground">BusinessApp</span>
      </div>

      {/* Navigation */}
      <nav className="mt-6 px-3">
        <div className="space-y-1">
          {navigationItems.map((item) => {
            const Icon = item.icon;
            const isActive = location === item.href || (item.href === "/dashboard" && location === "/");
            
            return (
              <Link key={item.href} href={item.href}>
                <a
                  className={cn(
                    "nav-link",
                    isActive ? "nav-link-active" : "nav-link-inactive"
                  )}
                >
                  <Icon className="mr-3 h-5 w-5" />
                  {item.label}
                </a>
              </Link>
            );
          })}
        </div>

        {/* Quick Actions */}
        <div className="mt-6 px-3">
          <Link href="/tasks/new">
            <Button className="w-full justify-start mb-2">
              <Plus className="mr-2 h-4 w-4" />
              Create New Task
            </Button>
          </Link>
        </div>

        {/* User Section */}
        <div className="mt-8 pt-6 border-t border-sidebar-border">
          <div className="flex items-center px-3 py-2">
            <Avatar className="h-8 w-8 mr-3">
              <AvatarImage src={user.avatar} alt={`${user.firstName} ${user.lastName}`} />
              <AvatarFallback>
                {user.firstName.charAt(0)}{user.lastName.charAt(0)}
              </AvatarFallback>
            </Avatar>
            <div className="flex-1">
              <p className="text-sm font-medium text-sidebar-foreground">
                {user.firstName} {user.lastName}
              </p>
              <p className="text-xs text-muted-foreground capitalize">{user.role}</p>
            </div>
            <Button
              variant="ghost"
              size="sm"
              onClick={logout}
              className="text-muted-foreground hover:text-sidebar-foreground"
            >
              <LogOut className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </nav>
    </div>
  );
}

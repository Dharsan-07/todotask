import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { formatDistanceToNow } from "date-fns";

interface ActivityItemProps {
  activity: {
    id: number;
    action: string;
    target?: string;
    createdAt: Date;
    user?: {
      firstName: string;
      lastName: string;
      avatar?: string;
    } | null;
  };
  icon: React.ReactNode;
}

export function ActivityItem({ activity, icon }: ActivityItemProps) {
  const timeAgo = formatDistanceToNow(new Date(activity.createdAt), { addSuffix: true });

  return (
    <div className="flex items-start space-x-3 p-3 hover:bg-muted/50 rounded-lg">
      <Avatar className="h-8 w-8">
        <AvatarImage src={activity.user?.avatar} />
        <AvatarFallback>
          {activity.user?.firstName.charAt(0)}{activity.user?.lastName.charAt(0)}
        </AvatarFallback>
      </Avatar>
      <div className="flex-1">
        <p className="text-sm text-foreground">
          <span className="font-medium">
            {activity.user?.firstName} {activity.user?.lastName}
          </span>{" "}
          <span>{activity.action}</span>
          {activity.target && (
            <span className="font-medium text-primary"> "{activity.target}"</span>
          )}
        </p>
        <p className="text-xs text-muted-foreground mt-1">{timeAgo}</p>
      </div>
      <div className="text-sm">
        {icon}
      </div>
    </div>
  );
}

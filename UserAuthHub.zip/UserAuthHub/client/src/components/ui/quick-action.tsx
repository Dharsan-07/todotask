import { Button } from "@/components/ui/button";
import { LucideIcon } from "lucide-react";
import { ChevronRight } from "lucide-react";
import { cn } from "@/lib/utils";

interface QuickActionProps {
  icon: LucideIcon;
  iconColor: string;
  label: string;
  onClick: () => void;
}

export function QuickAction({ icon: Icon, iconColor, label, onClick }: QuickActionProps) {
  return (
    <Button
      variant="ghost"
      className="w-full flex items-center justify-between p-3 h-auto hover:bg-muted/50"
      onClick={onClick}
    >
      <div className="flex items-center">
        <div className={cn(
          "h-8 w-8 rounded-lg flex items-center justify-center mr-3",
          iconColor
        )}>
          <Icon className="h-4 w-4" />
        </div>
        <span className="text-sm font-medium">{label}</span>
      </div>
      <ChevronRight className="h-4 w-4 text-muted-foreground" />
    </Button>
  );
}
